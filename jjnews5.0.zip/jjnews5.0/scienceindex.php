<!-- <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title>Canuckington Post</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link href="css/global.css" rel="stylesheet" type="text/css" media="screen" charset="utf-8" />
</head> -->
<html lang="en"> 
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=.28">
  <link href="css/global.css" rel="stylesheet" type="text/css" />
  <link href='https://fonts.googleapis.com/css?family=Anek Latin' rel='stylesheet'/>
  <title>JJ-News</title>
</head>
<body>
  
</body>
</html> 
<body>
<!-- BEGIN TOP -->
<div id="top">
  <ul>
    <!-- <li><a href="#">About</a></li> -->
    <!-- <li><a href="#">Submit a Story</a></li> -->
    <!-- <li><a href="#">Feedback</a></li> -->
    <li><a href="#">தொடர்புக்கு</a></li>
  </ul>
</div>
<!-- END TOP -->
<!-- BEGIN HEADER -->
<div id="header">
  <div id="logo"> <a href=""><img src="img/news.png" style="height: 90px; width: 410px; margin-top:10px;" alt="" /></a> </div>
  <div id="ad"> <img src="img/ad-1.jpg" style="width: 480px; height:80px; margin-left: 80px; " /> </div>
</div>
<!-- END HEADER -->
<!-- BEGIN NAV -->
<div id="nav">
   <ul>
    <li><a href="index.php">முகப்பு</a></li>
    <!-- <li><a href="#">Archive</a></li> -->
    <li><a href="tutyindex.php">தூத்துக்குடி</a></li>
    <li><a href="politicsindex.php">அரசியல்</a></li>
    <li><a href="tamilnaduindex.php">தமிழ்நாடு </a></li>
    <li><a href="indiaindex.php">இந்தியா</a></li>
        <li><a href="cinimaindex.php">சினிமா </a></li>

    <li><a href="scienceindex.php">அறிவியல்  &amp;  தொழில்நுட்பம்</a></li>  
    <li><a href="sportsindex.php">விளையாட்டு</a></li>
    
    <li class="last"><a href="contact.php">Contact</a></li>
  </ul>
</div>
<!-- END NAV -->
<!-- BEGIN SUB NAV -->
<!-- <div id="sub-nav">
  <ul>
    <li class="title">Stay in the know:</li>
    <li><a href="#">Blogs</a></li>
    <li>|</li>
    <li><a href="#">Video Gallery</a></li>
    <li>|</li>
    <li><img src="img/icons/rss.png" alt="" /><a href="#">Subscribe</a></li>
    <li>|</li>
    <li><img src="img/icons/twitter.png" alt="" /><a href="#">Twitter</a></li>
  </ul>
</div> -->
<!-- END SUB NAV -->
<!-- BEGIN CONTENT WRAPPER -->
<div id="content-wrapper">

  
  <!-- BEGIN MAIN -->
  <div id="main">
    <div id="headlines">
      <div id="main-headline">
            <?php
include('connect.php');
$sql="SELECT * FROM `Science` ORDER BY id DESC LIMIT 3";

if($result=mysqli_query($link,$sql)){
if(mysqli_num_rows($result)>0){
 
  while($row= mysqli_fetch_array($result))
  {
    



?>
        <h2 class="heading">சிறப்பு பார்வை</h2>
        <img src="newsimages/<?php echo$row['image1'];?>" alt="" />
        <h1 ><a href="sciencedetail.php?id=<?php echo$row['id'];?>"> <?php echo$row['heading'];?></a> </h1>
        <p class="author">ஜெபா | <span><?php echo$row['createdat'];?></span></p>
        <p></p>
        <p><a href="#">வாசிக்க  &raquo;</a></p>

      <?php }}}?>
       
        <h2 class="heading">சமீபத்திய காட்சிகள்</h2>
        <?php
      include('connect.php');
$sql="SELECT*FROM video  ORDER BY id DESC Limit 1";
if($result=mysqli_query($link,$sql)){
if(mysqli_num_rows($result)>0){
 
  while($row= mysqli_fetch_array($result))
  {


?>
        <iframe width="400" height="400" src="<?php echo$row['v3'];?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

        <h2><a href="video.php">புதிய காணொளிகள்</a></h2>
        <p class="author"><span>09.18.09</span></p>
        <p><a href="video.php">மேலும் காண்க &raquo;</a></p>
        <iframe width="400" height="400" src="<?php echo$row['v6'];?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              <?php }}}?>


      </div>
      <div id="more-headlines">

                   <?php
include('connect.php');
$sql="SELECT * FROM `Science` LIMIT 4";

if($result=mysqli_query($link,$sql)){
if(mysqli_num_rows($result)>0){
 
  while($row= mysqli_fetch_array($result))
  {
    



?>
        <h2 class="heading">சமீபத்திய செய்திகள்</h2>

        <img src="newsimages/<?php echo$row['image2'];?>" style="width: 220px;height:180px;" alt="" class="right" />
        <h2><a href="sciencedetail.php?id=<?php echo$row['id'];?>"><?php echo$row['heading'];?></a></h2>
        <p class="author">ஜெபா | <span><?php echo$row['createdat'];?></span></p>
        <p><a href="#">வாசிக்க &raquo;</a></p>
  <?php }}} ?>
  


        <!-- <img src="img/beggar.jpg" style="width: 220px;height:180px;" alt="" class="right" /> -->
             </div>
    </div>
  </div>
  <!-- END MAIN -->
  <!-- BEGIN SIDEBARS -->
  <div id="sidebars">
     <!-- BEGIN ADS -->
    <a href="#"><img src="img/ad-2.jpg" alt="" class="ad" /></a> <a href="#"><img src="img/ad-3.jpg" alt="" class="ad" /></a> <a href="#"><img src="img\ad-4.jpg" alt="" class="ad" /></a> <a href="#"><img src="img/ad-5.jpg" alt="" class="ad" /></a>
    <!-- END ADS -->
              <?php
include('connect.php');
$sql="SELECT * FROM `sports` ORDER BY id DESC LIMIT 1";

if($result=mysqli_query($link,$sql)){
if(mysqli_num_rows($result)>0){
 
  while($row= mysqli_fetch_array($result))
  {
    



?>

    <h2 >விளையாட்டு செய்திகள்</h2>
    <img src="newsimages/<?php echo$row['image2'];?>" style="height: 250px; width: 300px;" alt="" />
    <h3><a href="sportsdetail.php?id=<?php echo$row['id'];?>"><b><?php echo$row['heading'];?>...</b></p>

    <?php }}}?>
    <p><a href="#">மேலும் காண்க &raquo;</a></p>
    <h2 class="heading">பிரபலங்கள்</h2>
    
                   <?php
include('connect.php');
$sql="SELECT * FROM `cinima` ORDER BY id DESC LIMIT 2";

if($result=mysqli_query($link,$sql)){
if(mysqli_num_rows($result)>0){
 
  while($row= mysqli_fetch_array($result))
  {
    



?>
     <img src="newsimages/<?php echo$row['image1'];?>" alt="" class="ad-right" />

  <h3><a href="cinimadetail.php?id=<?php echo$row['id'];?>"><?php echo$row['heading'];?>...</a></h3>

  <?php }}}?>

  </div>
  <!-- END SIDEBARS -->
</div>
<!-- END CONTENT WRAPPER-->
<!-- BEGIN EXTRAS -->
<div id="extras">
  <div id="recommended">
    <h2 class="heading">Recommended Stories</h2>

               <?php
include('connect.php');
$sql="SELECT * FROM `sports` ORDER BY id DESC LIMIT 2";

if($result=mysqli_query($link,$sql)){
if(mysqli_num_rows($result)>0){
 
  while($row= mysqli_fetch_array($result))
  {
    



?>

    <ul>
      <li><a href="sportsdetail.php?id=<?php echo$row['id'];?>"><?php echo$row['heading'];?> &raquo;</a></li>
    
    </ul>
    <?php }}}?>
  </div>

  <div id="programs">
    <h2 class="heading">இன்றைய நிகழ்வுகள்</h2>
    <img src="img/rick.jpg" alt="" /> <img src="img/cbc.png" alt="" /> </div>
  <div id="cartoon">
    <h2 class="heading">கேளிக்கைகள்</h2>
    <img src="img/cartoon.jpg" alt="" /> </div>
</div>
<!-- END EXTRAS -->
<!-- BEGIN FOOTER -->
<div id="footer">
  <ul>
    <li>&copy;2023 <a href="#">ஜெபா</a></li>
    <li>|</li>
    <li><a href="#">FAQ</a></li>
    <li>|</li>
    <li><a href="#">Privacy Policy</a></li>
    <li>|</li>
    <li><a href="#">Careers</a></li>
    <li>|</li>
    <li><a href="#">Advertise</a></li>
    <li>|</li>
    <!-- <li><a href="#">Sitemap</a></li> -->
    <li>|</li>
    <!-- <li>Designed by <a href="http://www.skyrocketlabs.com/">Skyrocket Labs</a></li> -->
  </ul>
</div>
<!-- END FOOTER -->
</body>
</html>
