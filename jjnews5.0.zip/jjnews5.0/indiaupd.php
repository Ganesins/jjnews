<?php 
include('connect.php');
if (isset($_POST['submit'])) {
    $id = $_POST['hide1'];
    $image1 = $_FILES['image1']['name'];
    $tmp_name1 = $_FILES['image1']['tmp_name'];
    $image2 = $_FILES['image2']['name'];
    $tmp_name2 = $_FILES['image2']['tmp_name'];
    $target_path = "newsimages/";
    $target_path1 = $target_path . basename($image1);
    $target_path2 = $target_path . basename($image2);
    move_uploaded_file($tmp_name1, $target_path1);
    move_uploaded_file($tmp_name2, $target_path2);
    $heading = $_POST['heading'];
    $para = $_POST['para'];
    $tag = $_POST['tag'];
    
    $sql = "SELECT image1, image2 FROM India WHERE id='$id'";
    $result = mysqli_query($link, $sql);
    $row = mysqli_fetch_assoc($result);
    $old_image1 = $row['image1'];
    $old_image2 = $row['image2'];
    
    if ($old_image1 != '') {
        $old_path1 = "newsimages/" . $old_image1;
        if (file_exists($old_path1)) {
            unlink($old_path1);
        }
    }
    
    if ($old_image2 != '') {
        $old_path2 = "newsimages/" . $old_image2;
        if (file_exists($old_path2)) {
            unlink($old_path2);
        }
    }
    
    $sql = "UPDATE India SET image1='$image1', image2='$image2', heading='$heading', para='$para', tag='$tag' WHERE id='$id'";
    if (mysqli_query($link, $sql)) {
        echo '<script>alert("Data updated successfully!"); window.location = "indiaedit.php";</script>';
    } else {
        echo "Error updating record: " . mysqli_error($link);
    }
    mysqli_close($link);
}
?>