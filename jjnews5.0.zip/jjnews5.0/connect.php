        <?php
$link=mysqli_connect("localhost","root","","new");
if($link==false)
{
  die("error:cant connect".mysqli_connect_error());

}
?>