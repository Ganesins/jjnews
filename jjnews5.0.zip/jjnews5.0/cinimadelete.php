<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body> 
	<?php
	$v1=$_GET['id'];

	include('connect.php');

	$sql="DELETE FROM `cinima` WHERE id='$v1'";

	if(mysqli_query($link,$sql))
	{
		echo $v1,"record deleted";
	}
	else
	{
		echo"cant excecute".mysql_error($link);
	}
	mysqli_close($link)
	?>

</body>
</html>