<!DOCTYPE html>
<html>

<head>
    <title>Image Upload in PHP</title>
    <style>
        #wrapper {
            width: 50%;
            margin: 20px auto;
            border: 2px solid #dad7d7;
        }

        form {
            width: 50%;
            margin: 20px auto;
        }

        form div {
            margin-top: 5px;
        }

        img {
            float: left;
            margin: 5px;
            width: 280px;
            height: 120px;
        }

        #img_div {
            width: 70%;
            padding: 5px;
            margin: 15px auto;
            border: 1px solid #dad7d7;
        }

        #img_div:after {
            content: "";
            display: block;
            clear: both;
        }
    </style>
</head>

<body style="margin-top:150px;">
    <div id="wrapper">
        <form method="POST" action="" enctype="multipart/form-data">
            <input type="file" name="choosefile" value="" />
            <div>
                <button type="submit" name="uploadfile">UPLOAD</button>
            </div>
        </form>
    </div>
    <?php
    if (isset($_POST['uploadfile'])) {
        $filename = $_FILES["choosefile"]["name"];
        $tempname = $_FILES["choosefile"]["tmp_name"];
        $folder = "img/" . $filename;
        $db = mysqli_connect("localhost", "root", "", "Image_Upload");

        $select_query = "SELECT filename FROM image WHERE filename='$filename'";
        $result = mysqli_query($db, $select_query);
        if (mysqli_num_rows($result) > 0) {
            $delete_query = "DELETE FROM image WHERE filename='$filename'";
            mysqli_query($db, $delete_query);
        }

        $sql = "INSERT INTO image (filename) VALUES ('$filename')";
        mysqli_query($db, $sql);

        if (move_uploaded_file($tempname, $folder)) {
            $msg = "Image uploaded successfully";
        } else {
            $msg = "Failed to upload image";
        }
    }
    ?>
</body>

</html>
