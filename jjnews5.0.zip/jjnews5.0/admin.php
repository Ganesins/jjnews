<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link href="css/global.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  </head>
  <body style="font-size:20px;">
 <center id="wrapper"><br>

  <h1><b>WelcomeAdmin</b></h1>
<div style="font-size:35px;" >
Add content <a href="adcontent.php"> <i class="fa fa-plus" style="font-size:24px"></i></a><br>
Edit Content  <a href="display.php"><i class="fa fa-edit" style="font-size:24px"></i></a><br>
Add youtube video <a href="youtube.php"> <i class="fa fa-plus" style="font-size:24px"></i></a><br>

  
</div>
<div class="ad">
  <form method="post" action="">

  

  AD-1  &nbsp;  <a href="upload.php"><i  class="fa fa-upload"  style="font-size:24px" ></i></a>&nbsp;&nbsp;(ad-1.jpg)<br>
<br>
  
AD-2  &nbsp;  <a href="upload.php"><i  class="fa fa-upload"  style="font-size:24px" ></i></a>&nbsp;&nbsp;(ad-2.jpg)<br>
<br>

  
AD-3 &nbsp;   <a href="upload.php"><i  class="fa fa-upload"  style="font-size:24px" ></i></a>&nbsp;&nbsp;(ad-3.jpg)<br>
<br>

  
AD-4 &nbsp;   <a href="upload.php"><i  class="fa fa-upload"  style="font-size:24px" ></i></a>&nbsp;&nbsp;(ad-4.jpg)<br>
<br>
  
AD-5 &nbsp;   <a href="upload.php"><i  class="fa fa-upload"  style="font-size:24px" ></i></a>&nbsp;&nbsp;(ad-5.jpg)<br>
<br><br>

  

  <input type="submit" name="" value="save">
</form>
  </div>

 </center>

  </body>
  </html>