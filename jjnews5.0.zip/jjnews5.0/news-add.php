<?php
// Initialize the $conn variable
$conn = null;

// Connect to the database
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "new";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}


// Get the form data
$image1 = $_FILES['image1']['name'];
$image2 = $_FILES['image2']['name'];
$heading = $_POST['heading'];
$para = $_POST['para'];
$tag = $_POST['tag'];

// Set the destination folder
$target_dir = "newsimages/";

// Move the uploaded image1 to the destination folder
if (move_uploaded_file($_FILES['image1']['tmp_name'], $target_dir . basename($_FILES['image1']['name']))) {
  // The file has been moved successfully
} else {
  // There was an error moving the file
}

// Move the uploaded image2 to the destination folder
if (move_uploaded_file($_FILES['image2']['tmp_name'], $target_dir . basename($_FILES['image2']['name']))) {
  
} else {
  // There was an error moving the file
}

// Insert the data into the database
$sql="INSERT INTO `$tag` (image1,image2,heading,para,tag) VALUES ('$image1','$image2','$heading','$para','$tag')";
if (mysqli_query($conn,$sql)) {
  // Data was added to the database successfully
  echo '<script>alert("Data added successfully!"); window.location = "admin.php";</script>';
} else {
  // There was an error adding the data to the database
  echo "Error: ".mysqli_error($conn);
}






?>
<!-- CREATE TABLE `new`.`TamilNadu` ( `id` INT(222) NOT NULL AUTO_INCREMENT , `image1` VARCHAR(222) NULL , `image2` VARCHAR(222) NULL , `heading` VARCHAR(222) NULL , `para` VARCHAR(222) NULL , `tag` VARCHAR(222) NULL , `createdat` TIMESTAMP(222) NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;  -->
