<?php
$a1=$_POST['v1'];
$a2=$_POST['v2'];
$a3=$_POST['v3'];
$a4=$_POST['v4'];
$a5=$_POST['v5'];
$a6=$_POST['v6'];
$id=$_POST['id'];



$link=mysqli_connect("localhost","root","","new");
if($link==false)
{
	
	die("error can't connected".mysqli_connect_error());
}

$sql="UPDATE `video` SET v1='$a1',v2='$a2',v3='$a3',v4='$a4',v5='$a5',v6='$a6' WHERE id=$id";

if(mysqli_query($link,$sql))
{

  echo '<script>alert("Data updated successfully!"); window.location = "admin.php";</script>';
}
else
{
	echo "unable to excecute".mysqli_error($link);
}

mysqli_close($link)
?>
