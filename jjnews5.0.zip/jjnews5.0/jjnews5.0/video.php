<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Trending Videos</title>
    <style>
      * {
        box-sizing: border-box;
      }
      /* .ad {
  flex: 1 1 300px;
  max-width: 300px;
  margin: 10px;
  position: relative;
  text-align: center;
}
.ad img {
  width: 100%;
  height: auto;
} */

      body {
        font-family: Arial, sans-serif;
        margin: 0;
      }
      .header {
        background-color: #f1f1f1;
        padding: 20px;
        text-align: center;
      }
      .container {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  margin: 20px;
}
      .video {
  flex: 1 1 300px;
  max-width: 400px;
  margin: 10px;
  text-align: center;
  position: relative;
  padding: 10px;
}
      .video iframe {
        width: 100%;
        height: 250px;
      }
      .video h3 {
        margin-top: 10px;
        font-size: 18px;
        color: #444;
        text-align: center;
      }
      #sidebars img.ad, #sidebars img.ad-right {
  margin: 0 24px 24px 0;
  border: 0;
  height: 225px;
  width: 225px;
}
#sidebars {
  float: right;
  width: 279px;
  min-height: 630px;
  padding: 0 0 0 20px;
  border-left: 1px solid #ddd;
}
      /* .ad {
  flex: 1 1 300px;
  max-width: 300px;
  margin: 10px;
  position: relative;
  text-align: right;
  flex-direction: column-reverse;
  align-items: flex-end;
} */
/* 
      .ad img {
        width: 100%;
        height: auto;
      }
      .premium-ad {
        position: absolute;
        top: 10px;
        right: 10px;
        z-index: 1;
      }
      .premium-ad img {
        width: 100%;
        height: auto;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
      } */
      .video:hover {
        transform: scale(1.03);
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
      }
    </style>
  </head>
  <body>
    <div class="header">
      <h1>Trending Videos</h1>
    </div>
    <div id="sidebars">
      <!-- BEGIN ADS -->
     <a href="#"><img src="img/ad-2.jpg" alt="" class="ad" /></a> <a href="#"><img src="img/ad-3.jpg" alt="" class="ad" /></a> <a href="#"><img src="img\ad-4.jpg" alt="" class="ad" /></a> <a href="#"><img src="img/ad-5.jpg" alt="" class="ad" /></a>
     <!-- END ADS -->
    </div>
    <div class="container">
      <div class="video">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/VIDEO_ID_1" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        <h3>Video Title 1</h3>
      </div>
      <div class="video">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/VIDEO_ID_2" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        <h3>Video Title 2</h3>
      </div>
      <div class="video">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/VIDEO_ID_3" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        <h3>Video Title 3</h3>
      </div>
      <div class="video">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/VIDEO_ID_4" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        <h3>Video Title 4</h3>
      </div>
      <div class="video">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/VIDEO_ID_5" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        <h3>Video Title 5</h3>
      </div>
      <div class="video">
        <iframe width="560" height="315" src="https://www.youtube.com/embed/VIDEO_ID_6" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        <h3>Video Title 6</h3>
      </div>
    </div>
    
      </div>
    </div>
    <footer class= "suggestion">
      <!-- HTML Code -->
      <div class="suggested-articles">
        <h2>மேலும் தகவல்கள்</h2>
       
           <?php
            $a1=$_GET['id']; 
      include('connect.php'); 
      $sql="SELECT*FROM TamilNadu WHERE createdat < CURDATE() AND createdat >= DATE_SUB(CURDATE(), INTERVAL 3 DAY)  ORDER BY id DESC Limit 3 ";
      
      
      if($result=mysqli_query($link,$sql)){
      if(mysqli_num_rows($result)>0){
       
        while($row= mysqli_fetch_array($result))
        {
      
      
      ?>
      
        <ul>
          <li>
            <img src="img/<?php echo$row['image1'];?>" alt="Article 1 Image">
            <a href="tamilnadudetail.php?id=<?php echo$row['id'];?>"> 
              <?php echo$row['heading'];?></a>
          </li>
        </ul>
                              <?php  }  } } ?>
      
      </div>
      </footer>
  </body>
</html>
