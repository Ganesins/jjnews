<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>youtube</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link href="css/global.css" rel="stylesheet" type="text/css" />

  </head>
  <body style="margin-top:8%;">
    <div id="wrapper">
    <center ><br>


    	<form action="videoupd.php" method="post">
    	<h1>Add youtube videos</h1>
    	 	  <?php
include('connect.php');
$sql="SELECT*FROM video  ORDER BY id DESC Limit 1";
if($result=mysqli_query($link,$sql)){
if(mysqli_num_rows($result)>0){
 
  while($row= mysqli_fetch_array($result))
  {


?>
    	<label>vidio 1</label>
    	<input type="hidden" name="id" value="<?php echo$row['id'];?>" >

      <textarea name="v1"><?php echo$row['v1'];?></textarea>

      <br>
    	<label>vidio 2</label>
            <textarea name="v2"><?php echo$row['v2'];?></textarea>
      <br>
    	<label>vidio 3</label>
      <textarea name="v3"><?php echo$row['v3'];?></textarea>

      <br>
    	<label>vidio 4</label>
      <textarea name="v4"><?php echo$row['v4'];?></textarea>

      <br>
    	<label>vidio 5</label>
      <textarea name="v5"><?php echo$row['v5'];?></textarea>

      <br>
    	<label>vidio 6</label>
      <textarea name="v6"><?php echo$row['v6'];?></textarea>

      <br>
                         <?php  }  } } ?>

    <input type="submit" name="" value="Add">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </center><br> <br>
</div>
  </body>
</html>
