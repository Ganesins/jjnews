<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Addnews content</title>
  <link href="css/global.css" rel="stylesheet" type="text/css" />

  
</head>
<body style="margin-top:100px;" font-style:bold;> 
  <div id="wrapper">
    <center><br>
      <form action="news-add.php" method="post" enctype="multipart/form-data">
        <label>Image1</label>
        <input type="file" name="image1"><br><br>

        <label>Image2</label>
        <input type="file" name="image2"><br><br> 

        <label>Heading</label>
        <textarea type="text" name="heading"></textarea><br><br>

        <label>para</label>
        <textarea type="text" name="para"></textarea><br><br>

        <label>Tag</label>
        <select name="tag" id="tag">
          <option>Select Tag</option>
          <option value="thoothukudi">thoothukudi</option>
          <option value="TamilNadu">TamilNadu</option>
          <option value="India">India</option>
          <option value="sports">sports</option>
          <option value="Politics">Politics</option>
          <option value="Science">Science</option>
          <option value="cinima">cinima</option>

        </select><br><br>
        <input type="submit" name="submit" value="Save">
      </form>
    </center><br>
  </div>
</body>
</html>
