<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>News Feed</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div id="news-feed">
    <?php
      // Connect to the database
      $conn = mysqli_connect("localhost", "root", "", "news");

      // Query the database for all news articles
      $result = mysqli_query($conn, "SELECT * FROM news_articles");

      // Loop through each news article and display it
      while ($row = mysqli_fetch_assoc($result)) {
        echo "<div class='news-article'>";
        echo "  <img src='".$row['image1']."' alt='Article Image'>";
        echo "  <h2>".$row['heading']."</h2>";
        echo "  <p>".$row['para']."</p>";
        echo "  <p class='article-info'>Tag: ".$row['tag']."</p>";
        echo "</div>";
      }
    ?>
  </div>
</body>
</html>
