<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<center>


  <h1>EDit</h1>
  <a href="tamilnaduedit.php">TAMIL NADU</a><br>
  <a href="thoothukudiedit.php">Thoothukudi</a><br>
  <a href="indiaedit.php">India</a><br>
  <a href="politicsedit.php">Politics</a><br>
  <a href="scienceedit.php">Science</a><br>
  <a href="sportsedit.php">Sports</a><br>
  <a href="cinimaedit.php">Cinima</a><br>
</center>

</body>
</html>