<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Addnews content</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head> 
<body>
	<?php
		$a1 = $_GET['id']; 

		include('connect.php');
		$sql = "SELECT * FROM Politics where id='$a1'";
		if ($result = mysqli_query($link, $sql)) {
			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_array($result)) {
	?>
	<form method="post" action="politicsupd.php" enctype="multipart/form-data">
		<h1>Edit Politics</h1>
		<input type="hidden" name="hide1" value="<?php echo$row['id'];?>">
		<label>image1</label>
		<input type="file" name="image1" value="<?php echo$row['image1'];?>" required >
		<label>image2</label>
		<input type="file" name="image2" value="<?php echo$row['image2'];?>" required><br><br>
		<center>
			<label>Heading</label>

			<textarea name="heading" ><?php echo$row['heading'];?></textarea><br><br>
			<label>para</label>
			<textarea  name="para"><?php echo$row['para'];?></textarea>

			<br><br>
			<label>Tag</label>
			<select name="tag" id="tag">
				<option value="politicsedit.php">Politics</option>
			</select><br><br>
			<input type="submit" name="submit" value="save">
		</center>
	</form>

	<?php  
				}
			}
		} 
	?>
</body>
</html>
