<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=.28">
  <link href="css/global.css" rel="stylesheet" type="text/css" />
  <link href='https://fonts.googleapis.com/css?family=Anek Latin' rel='stylesheet'/>
  <style>
    /* CSS Code */
.suggested-articles {
  width: 1000px;
  margin: 0 auto;
  text-align: center;
}

.suggested-articles h2 {
  font-size: 22px;
  margin-bottom: 20px;
  padding-left: 180px;
  background-color:;
  
}

.suggested-articles ul {
  list-style: none;
  padding: 0;
}

.suggested-articles li {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}
body{
  padding:10px;
}

.suggested-articles img {
  width: 120px;
  height: 120px;
  margin-right: 10px;
}

.suggested-articles a {
  font-size: 19px;
  text-decoration: none;
  color: #333;
  width:100%;
  font-style:bold;
}
.suggestion{
  position: relative;
  height:100%;
  width:100%;
  backgound-color: #E4DEDD;
    margin-top: 20%;

}






  </style>
  <title>Document</title>
</head>
<body>

<body>

     <?php
      $a1=$_GET['id']; 
include('connect.php'); 
$sql="SELECT*FROM sports where id= '$a1'";
if($result=mysqli_query($link,$sql)){
if(mysqli_num_rows($result)>0){
 
  while($row= mysqli_fetch_array($result))
  {


?>





  <!-- BEGIN TOP -->
<div id="top">
  <ul>
    <!-- <li><a href="#">About</a></li> -->
    <!-- <li><a href="#">Submit a Story</a></li> -->
    <!-- <li><a href="#">Feedback</a></li> -->
    <li><a href="#">தொடர்புக்கு</a></li>
  </ul>
</div>
<!-- END TOP -->
<!-- BEGIN HEADER -->
<div id="header">
  <div id="logo"> <a href="#"><img src="img/news.png" style="height: 90px; width: 410px; margin-top:10px;" alt="" /></a> </div>
  <div id="ad"> <img src="img/ad-1.jpg" style="width: 480px; height:80px; margin-left: 80px; " /> </div>
</div>
<!-- END HEADER -->
<!-- BEGIN NAV -->
<div id="nav">
   <ul>
    <li><a href="index.php">முகப்பு</a></li>
    <!-- <li><a href="#">Archive</a></li> -->
    <li><a href="tutyindex.php">தூத்துக்குடி</a></li>
    <li><a href="politicsindex.php">அரசியல்</a></li>
    <li><a href="tamilnaduindex.php">தமிழ்நாடு </a></li>
    <li><a href="indiaindex.php">இந்தியா</a></li>
    <li><a href="scienceindex.php">அறிவியல்  &amp;  தொழில்நுட்பம்</a></li>  
    <li><a href="sportsindex.php">விளையாட்டு</a></li>
    
    <li class="last"><a href="contact.php">Contact</a></li>
  </ul>
</div>
<!-- END NAV -->
<img src="newsimages/<?php echo$row['image1'];?>" alt="" style="width: 65%;height:60%;"><br>
<div id="sidebars">
    <!-- BEGIN ADS -->
    <a href="#"><img src="img/ad-2.jpg" alt="" class="ad" /></a> <a href="#"><img src="img/ad-3.jpg" alt="" class="ad" /></a> <a href="#"><img src="img\ad-4.jpg" alt="" class="ad" /></a> <a href="#"><img src="img/ad-5.jpg" alt="" class="ad" /></a>
    <!-- END ADS -->
</div>

        
<h1>

  <?php echo$row['heading'];?>.. <br></h1>
<img src="newsimages/<?php echo$row['image2'];?>" text-align="left"class="blog-2" HSPACE=”50” VSPACE=”50”/>
<?php echo$row['para'];?>
<?php }}}?>


<footer class= "suggestion">
<!-- HTML Code -->
<div class="suggested-articles">
  <h2>மேலும் தகவல்கள்</h2>

     <?php
      $a1=$_GET['id']; 
include('connect.php'); 
$sql="SELECT*FROM sports  WHERE createdat < CURDATE() AND createdat >= DATE_SUB(CURDATE(), INTERVAL 3 DAY)  ORDER BY id DESC Limit 3 ";


if($result=mysqli_query($link,$sql)){
if(mysqli_num_rows($result)>0){
 
  while($row= mysqli_fetch_array($result))
  {


?>

  <ul>
    <li>
      <img src="newsimages/<?php echo$row['image1'];?>" alt="Article 1 Image">
      <a href="sportsdetail.php?id=<?php echo$row['id'];?>"> 
        <?php echo$row['heading'];?></a>
    </li>
  </ul>
                        <?php  }  } } ?>

</div>
</footer>
</tr>
</body>
</html>



